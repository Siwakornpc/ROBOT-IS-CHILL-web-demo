export type AutocompleteContext = {
    type: "macro" | "variant" | "flag" | "tile";
    query: string;
    startIndex: number;
};

export function getAutocompleteContext(
    value: string, 
    caretPos: number, 
    isRenderMode: boolean
): AutocompleteContext | null {
    const lineStart = value.lastIndexOf("\n", caretPos - 1) + 1;
    const textBeforeCaret = value.slice(lineStart, caretPos);
    
    // check if macro
    const lastOpenBracket = textBeforeCaret.lastIndexOf("[");
    const lastCloseBracket = textBeforeCaret.lastIndexOf("]");
    
    if (lastOpenBracket > lastCloseBracket) {
        const query = textBeforeCaret.slice(lastOpenBracket + 1);
        return {
            type: "macro",
            query,
            startIndex: lineStart + lastOpenBracket + 1 
        };
    }
    
    if (isRenderMode) {
        // check if variant
        const colonIndex = textBeforeCaret.lastIndexOf(":");
        if (colonIndex !== -1) {
            const afterColon = textBeforeCaret.slice(colonIndex);
            if (!/\s/.test(afterColon)) {
                const query = textBeforeCaret.slice(colonIndex + 1);
                return {
                    type: "variant",
                    query,
                    startIndex: lineStart + colonIndex + 1
                };
            }
        }
        
        //check if flag
        const lastDash = textBeforeCaret.lastIndexOf("-");
        if (lastDash !== -1) {
            const charBeforeDash = textBeforeCaret[lastDash - 1];
            // Ensure dash is at start of line or preceded by whitespace
            if (lastDash === 0 || /\s/.test(charBeforeDash)) {
                const isDoubleDash = textBeforeCaret[lastDash + 1] === "-";
                const flagStartIndex = isDoubleDash ? lastDash + 2 : lastDash + 1;
                
                const afterDash = textBeforeCaret.slice(flagStartIndex);
                if (!/\s/.test(afterDash)) {
                    return {
                        type: "flag",
                        query: afterDash,
                        startIndex: lineStart + flagStartIndex,
                    };
                }
            }
        }
    }
    
    return null;
}