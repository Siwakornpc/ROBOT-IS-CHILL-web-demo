const escapeHtml = (str) => str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");

const span = (className, textValue, kind = "", id = -1, depth = 0, pos = -1) => {
    if (kind === "open" || kind === "close") {
        return `<span class="${className} ${kind}-bracket bracket-level-${depth % 3}" data-bid="${id}" data-pos="${pos}">${escapeHtml(textValue)}</span>`;
    }

    const position = pos >= 0 ? ` data-pos="${pos}"` : "";
    return `<span class="${className}"${position}>${escapeHtml(textValue)}</span>`;
};

// Shared escape-aware bracket pairing. Used both to know which "]" closes
// which "[" (validPairs) and to find the top-level (depth 0) [...] ranges,
// which is what combined-highlight.js needs to know where macro syntax
// "takes over" from render syntax.
const findBracketPairsInternal = (text) => {
    const validPairs = new Map();
    const pairStack = [];
    const topLevel = [];

    for (let i = 0; i < text.length; i++) {
        if (text[i] === "\\") {
            i++;
        }
        else if (text[i] === "[") {
            pairStack.push(i);
        }
        else if (text[i] === "]" && pairStack.length) {
            const open = pairStack.pop();
            validPairs.set(open, i);
            if (pairStack.length === 0) {
                topLevel.push([open, i]);
            }
        }
    }

    return { validPairs, topLevel };
};

const specialTokens = [
    { regex: /^\$-?\d+/, className: "macro-custom-argument" },
    { regex: /^\$!/, className: "macro-custom-executor-mode" },
    { regex: /^\$#/, className: "macro-custom-argument-count" },
];

// Builds the raw token list (same tokens macroHighlighter used to build
// inline). Kept separate so both macroHighlighter (joined string) and
// macroHighlightSegments (positioned pieces, for combined-highlight.js)
// can share one tokenizing pass.
const buildMacroTokens = (text) => {
    const { validPairs } = findBracketPairsInternal(text);

    const tokens = [];
    const appendText = (textValue, className = "", pos = -1) => {
        const previous = tokens.at(-1);

        if (
            previous
            && previous.type === "text"
            && previous.className === className
            && previous.pos + previous.text.length === pos
        ) {
            previous.text += textValue;
            return;
        }

        tokens.push({ type: "text", text: textValue, className, pos });
    };

    let bracketId = 0;
    const stateStack = [];
    const bracketStack = [];
    const escapable = new Set(["[", "]", "/", "\\", "$"]);

    for (let i = 0; i < text.length; i++) {
        const ch = text[i];
        const next = text[i + 1];

        // "\n" is always emitted as its own plain/uncoloured token, regardless of
        // bracket depth or name/value state. This does two things: it keeps a
        // multi-line macro call (name or value text that continues across a line
        // break) tokenizing correctly, since state carries through untouched, and
        // it guarantees no <span> ever contains a literal newline - callers can
        // safely split the rendered HTML on "\n" to get one chunk per source line
        // without ever splitting a tag in half.
        if (ch === "\n") {
            appendText(ch, "", i);
        }

        else if (ch === "\\" && next && escapable.has(next)) {
            const state = stateStack.at(-1);
            appendText(ch + next, state === "value" ? "macro-value-escape" : "escape", i);
            i++;
        }
        
        else if (ch === "[" && validPairs.has(i)) {
            const id = bracketId++;
            const empty = validPairs.get(i) === i + 1 || next === "/";
            bracketStack.push({ id, close: validPairs.get(i), empty });
            stateStack.push("name");
            tokens.push({
                type: "bracket",
                pos: i,
                length: 1,
                html: span(empty ? "macro-empty" : "macro-brackets", "[", "open", id, bracketStack.length - 1, i),
            });
        }
        else if (ch === "]" && bracketStack.length && bracketStack.at(-1).close === i) {
            const item = bracketStack.pop();
            stateStack.pop();
            tokens.push({
                type: "bracket",
                pos: i,
                length: 1,
                html: span(item.empty ? "macro-empty" : "macro-brackets", "]", "close", item.id, bracketStack.length, i),
            });
        }
        else if (stateStack.length && ch === "/") {
            stateStack[stateStack.length - 1] = "value";
            appendText(ch, bracketStack.at(-1).empty ? "macro-empty" : "macro-arg-separator", i);
        }
        else if (stateStack.length) {
            const current = bracketStack.at(-1);
            const isValueState = stateStack.at(-1) === "value";
            const special = isValueState
                ? specialTokens.find(({ regex }) => regex.test(text.slice(i)))
                : null;

            if (special) {
                const value = text.slice(i).match(special.regex)[0];
                appendText(value, special.className, i);
                i += value.length - 1;
            }
            else {
                appendText(
                    ch,
                    current.empty ? "macro-empty" : (stateStack.at(-1) === "name" ? "macro-name" : "macro-value"),
                    i,
                );
            }
        }
        else {
            const special = specialTokens.find(({ regex }) => regex.test(text.slice(i)));
            if (special) {
                const value = text.slice(i).match(special.regex)[0];

                appendText(value, special.className, i);
                i += value.length - 1;
            } else {
                appendText(ch, "", i);
            }
        }
    }

    return tokens;
};

const tokenHtml = (token) => {
    if (token.type === "bracket") return token.html;

    if (token.text.includes("\n")) {
        return escapeHtml(token.text).replace(/\n/g, "<br>");
    }

    if (!token.className) return escapeHtml(token.text);
    return span(token.className, token.text, "", -1, 0, token.pos);
};

export const macroHighlighter = (text) => buildMacroTokens(text).map(tokenHtml).join("");

export const updateMacroStaticHighlight = (element, text) => {
    if (!element) return;

    element.innerHTML = macroHighlighter(text);
};
