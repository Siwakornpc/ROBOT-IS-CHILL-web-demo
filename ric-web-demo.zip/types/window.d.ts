interface Window {
    executionMode?: string;
}
